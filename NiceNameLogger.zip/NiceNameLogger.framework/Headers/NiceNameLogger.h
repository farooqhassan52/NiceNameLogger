//
//  NiceNameLogger.h
//  NiceNameLogger
//
//  Created by Rana Farooq on 20/07/2020.
//  Copyright © 2020 AmcoItSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NiceNameLogger.
FOUNDATION_EXPORT double NiceNameLoggerVersionNumber;

//! Project version string for NiceNameLogger.
FOUNDATION_EXPORT const unsigned char NiceNameLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceNameLogger/PublicHeader.h>


